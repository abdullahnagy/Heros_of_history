package com.example.heross

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
